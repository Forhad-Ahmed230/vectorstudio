// Main World Network & Composer Interceptor for Google Flow
(function() {
  if (window.__GRAVITY_INTERCEPTOR_ACTIVE__) return;
  window.__GRAVITY_INTERCEPTOR_ACTIVE__ = true;

  console.log('[interceptor] Gravity Flow Main World Interceptor active.');

  function detectMimeFromBase64(b64) {
    if (!b64 || typeof b64 !== 'string') return null;
    const clean = b64.replace(/^data:[^,]+,/, '').trim();
    if (clean.startsWith('iVBORw0KGgo')) return 'image/png';
    if (clean.startsWith('/9j/')) return 'image/jpeg';
    if (clean.startsWith('UklGR')) return 'image/webp';
    if (clean.startsWith('R0lGOD')) return 'image/gif';
    if (clean.startsWith('PHN2Zy') || clean.startsWith('PD94bWw')) return 'image/svg+xml';
    return null;
  }

  function normalizeDataUrl(input, fallbackMime = 'image/png') {
    if (!input || typeof input !== 'string') return '';
    const str = input.trim();
    if (str.startsWith('data:')) {
      const commaIdx = str.indexOf(',');
      if (commaIdx !== -1) {
        const b64Data = str.substring(commaIdx + 1);
        const detected = detectMimeFromBase64(b64Data);
        if (detected) {
          return `data:${detected};base64,${b64Data}`;
        }
        return str;
      }
      return str;
    }
    const detected = detectMimeFromBase64(str) || fallbackMime;
    return `data:${detected};base64,${str}`;
  }

  function isGoogleOAuthToken(str) {
    if (!str || typeof str !== 'string') return false;
    return str.startsWith('ya29.') && str.length > 30;
  }

  function storeToken(token) {
    if (!token || typeof token !== 'string') return;
    const clean = token.replace(/^Bearer\s+/i, '').trim();
    if (isGoogleOAuthToken(clean)) {
      window.__CAPTURED_BEARER_TOKEN__ = clean;
      window.__CAPTURED_BEARER_TIME__ = Date.now();
      try {
        localStorage.setItem('__gflow_bearer_token', clean);
        localStorage.setItem('__gflow_bearer_time', String(Date.now()));
      } catch (_) {}
      try {
        window.dispatchEvent(new CustomEvent('__GRAVITY_TOKEN_CAPTURED__', { detail: clean }));
      } catch (_) {}
    }
  }

  function extractTokenFromHeaders(headers) {
    if (!headers) return null;
    try {
      if (headers instanceof Headers) {
        return headers.get('authorization') || headers.get('Authorization');
      }
      if (Array.isArray(headers)) {
        for (const [k, v] of headers) {
          if (k && k.toLowerCase() === 'authorization') return v;
        }
      }
      if (typeof headers === 'object') {
        return headers['authorization'] || headers['Authorization'] || headers['AUTHORIZATION'];
      }
    } catch (_) {}
    return null;
  }

  // 1. Intercept fetch (both Request objects and URL strings)
  const origFetch = window.fetch;
  window.fetch = async function(input, init) {
    try {
      let auth = null;
      if (init && init.headers) {
        auth = extractTokenFromHeaders(init.headers);
      }
      if (!auth && input && typeof input === 'object' && input.headers) {
        auth = extractTokenFromHeaders(input.headers);
      }
      if (auth) {
        storeToken(auth);
      }
    } catch (_) {}

    const response = await origFetch.apply(this, arguments);

    // Check if this was a Flow generation request
    try {
      const url = (typeof input === 'string') ? input : (input && input.url ? input.url : '');
      const isMediaEndpoint = url && (
        url.includes('/flowMedia:batchGenerateImages') ||
        url.includes('/flowMedia:batchGenerateVideos') ||
        url.includes('batchGenerateImages') ||
        url.includes('batchGenerateVideos') ||
        url.includes('flowMedia')
      );
      if (isMediaEndpoint) {
        console.log('[interceptor] Flow media request detected:', url, 'status:', response.status);
        if (response.ok) {
          response.clone().json().then(async (data) => {
            const mediaList = (data && (data.media || data.images || data.generatedImages)) || [];
            if (Array.isArray(mediaList) && mediaList.length > 0) {
              console.log('[interceptor] Captured generated media payload from Google Flow:', mediaList.length, 'items');
              
              // Enrich items with Base64 directly in MAIN world where session cookies are active
              for (const item of mediaList) {
                const g = (item.image && item.image.generatedImage) || item.generatedImage || item.image || item;
                const fifeUrl = g.fifeUrl || item.fifeUrl || (item.image && item.image.fifeUrl) || g.url || '';
                let b64 = g.encodedImage || item.encodedImage || (item.image && item.image.encodedImage) || item.imageBytes || null;
                if (fifeUrl && !b64) {
                  try {
                    const resolved = fifeUrl.startsWith('/') ? (window.location.origin + fifeUrl) : fifeUrl;
                    const r = await fetch(resolved);
                    if (r.ok) {
                      const bl = await r.blob();
                      b64 = await new Promise(res => {
                        const fr = new FileReader();
                        fr.onloadend = () => res(String(fr.result || ''));
                        fr.onerror = () => res('');
                        fr.readAsDataURL(bl);
                      });
                    }
                  } catch (_) {}
                }
                if (b64) {
                  b64 = normalizeDataUrl(b64);
                  item.encodedImage = b64;
                  if (item.image) item.image.encodedImage = b64;
                }
              }

              window.__LAST_FLOW_MEDIA__ = { at: Date.now(), media: mediaList };
              try {
                window.postMessage({
                  source: 'gravity-interceptor',
                  type: '__GRAVITY_FLOW_MEDIA_GENERATED__',
                  media: mediaList
                }, '*');
              } catch (_) {}
              try {
                window.dispatchEvent(new CustomEvent('__GRAVITY_FLOW_MEDIA_GENERATED__', { detail: mediaList }));
              } catch (_) {}
            }
          }).catch(() => {});
        } else {
          response.clone().text().then(errText => {
            console.warn('[interceptor] Flow media generation failed on network level:', response.status, errText);
            try {
              window.postMessage({
                source: 'gravity-interceptor',
                type: '__GRAVITY_FLOW_MEDIA_ERROR__',
                status: response.status,
                error: errText
              }, '*');
            } catch (_) {}
            try {
              window.dispatchEvent(new CustomEvent('__GRAVITY_FLOW_MEDIA_ERROR__', {
                detail: { status: response.status, error: errText }
              }));
            } catch (_) {}
          }).catch(() => {});
        }
      }
    } catch (_) {}

    return response;
  };

  // 2. Intercept XMLHttpRequest
  const origOpen = XMLHttpRequest.prototype.open;
  const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function() {
    return origOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
    try {
      if (header && header.toLowerCase() === 'authorization' && isGoogleOAuthToken(value)) {
        storeToken(value);
      }
    } catch (_) {}
    return origSetHeader.apply(this, arguments);
  };

  // 3. Scan DOM on document ready for ya29 tokens
  function quickScan() {
    try {
      for (const s of document.querySelectorAll('script')) {
        if (s.textContent && s.textContent.includes('ya29.')) {
          const m = s.textContent.match(/ya29\.[A-Za-z0-9_-]{30,}/);
          if (m && m[0]) {
            storeToken(m[0]);
            break;
          }
        }
      }
    } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', quickScan, { once: true });
  } else {
    quickScan();
  }

  // 4. Expose MAIN World Slate & React submit helpers
  window.__GRAVITY_INSERT_PROMPT__ = function(text) {
    try {
      const slateRoot = document.querySelector('[data-slate-editor="true"]');
      if (slateRoot) {
        const fiberKey = Object.keys(slateRoot).find(k => k.startsWith('__reactFiber'));
        if (fiberKey) {
          let fiber = slateRoot[fiberKey];
          while (fiber) {
            const state = fiber.memoizedState && fiber.memoizedState.memoizedState;
            if (state && state.editor && typeof state.editor.insertText === 'function') {
              try {
                state.editor.select([]);
                state.editor.deleteFragment();
              } catch (_) {}
              state.editor.insertText(text);
              return true;
            }
            const props = fiber.memoizedProps;
            if (props && props.editor && typeof props.editor.insertText === 'function') {
              try {
                props.editor.select([]);
                props.editor.deleteFragment();
              } catch (_) {}
              props.editor.insertText(text);
              return true;
            }
            fiber = fiber.return;
          }
        }
      }
    } catch (e) {
      console.warn('[interceptor] Slate fiber insert failed:', e);
    }
    return false;
  };

  window.__GRAVITY_CLICK_SUBMIT__ = function() {
    try {
      const candidates = Array.from(document.querySelectorAll('button, [role="button"]'));
      let targetBtn = null;

      for (const b of candidates) {
        const label = (b.getAttribute('aria-label') || '').toLowerCase();
        if ((label.includes('generate') || label.includes('create') || label.includes('send') || label.includes('submit')) && !label.includes('download')) {
          targetBtn = b;
          break;
        }
      }

      if (!targetBtn) {
        for (const b of candidates) {
          const svg = b.querySelector('svg, i, span.material-icons, span.google-symbols');
          if (svg) {
            const h = svg.outerHTML.toLowerCase();
            if (h.includes('arrow') || h.includes('send') || h.includes('upward') || h.includes('forward')) {
              targetBtn = b;
              break;
            }
          }
        }
      }

      if (targetBtn) {
        const propKey = Object.keys(targetBtn).find(k => k.startsWith('__reactProps$') || k.startsWith('__reactEventHandlers$'));
        if (propKey && targetBtn[propKey] && typeof targetBtn[propKey].onClick === 'function') {
          try {
            targetBtn[propKey].onClick({ isTrusted: true, preventDefault() {}, stopPropagation() {} });
          } catch (_) {}
        }
        targetBtn.focus();
        targetBtn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
        targetBtn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
        targetBtn.click();
        return true;
      }
    } catch (e) {
      console.warn('[interceptor] React click submit failed:', e);
    }
    return false;
  };

  // 5. Listen for commands from isolated world (content.js)
  window.addEventListener('__GRAVITY_EXEC_INSERT_PROMPT__', (e) => {
    const res = window.__GRAVITY_INSERT_PROMPT__(e.detail || '');
    window.dispatchEvent(new CustomEvent('__GRAVITY_EXEC_INSERT_PROMPT_RESULT__', { detail: res }));
  });

  window.addEventListener('__GRAVITY_EXEC_CLICK_SUBMIT__', () => {
    const res = window.__GRAVITY_CLICK_SUBMIT__();
    window.dispatchEvent(new CustomEvent('__GRAVITY_EXEC_CLICK_SUBMIT_RESULT__', { detail: res }));
  });

  // 6. Direct Base64 extraction in MAIN world (has full access to blobs, cookies, canvases)
  window.addEventListener('__GRAVITY_EXTRACT_BASE64__', async (e) => {
    const { reqId, src } = (e && e.detail) || {};
    let b64 = '';
    try {
      if (src && src.startsWith('blob:')) {
        try {
          const resp = await fetch(src);
          if (resp.ok) {
            const blob = await resp.blob();
            b64 = await new Promise(res => {
              const fr = new FileReader();
              fr.onloadend = () => res(String(fr.result || ''));
              fr.onerror = () => res('');
              fr.readAsDataURL(blob);
            });
          }
        } catch (_) {}
      }

      if (!b64 && src) {
        try {
          const resolved = src.startsWith('/') ? (window.location.origin + src) : src;
          const resp = await fetch(resolved);
          if (resp.ok) {
            const blob = await resp.blob();
            b64 = await new Promise(res => {
              const fr = new FileReader();
              fr.onloadend = () => res(String(fr.result || ''));
              fr.onerror = () => res('');
              fr.readAsDataURL(blob);
            });
          }
        } catch (_) {}

        if (!b64) {
          const allEls = Array.from(document.querySelectorAll('img, video, canvas'));
          const el = allEls.find(i => (i.currentSrc || i.src || '') === src);
          if (el) {
            if (el.tagName === 'CANVAS') {
              try {
                b64 = el.toDataURL('image/png');
              } catch (_) {}
            } else if (el.tagName === 'IMG') {
              try {
                const c = document.createElement('canvas');
                c.width = el.naturalWidth || el.width || 800;
                c.height = el.naturalHeight || el.height || 600;
                const ctx = c.getContext('2d');
                ctx.drawImage(el, 0, 0);
                b64 = c.toDataURL('image/png');
              } catch (_) {}
            } else if (el.tagName === 'VIDEO') {
              try {
                const c = document.createElement('canvas');
                c.width = el.videoWidth || el.width || 800;
                c.height = el.videoHeight || el.height || 600;
                const ctx = c.getContext('2d');
                ctx.drawImage(el, 0, 0);
                b64 = c.toDataURL('image/png');
              } catch (_) {}
            }
          }
        }
      }
    } catch (err) {
      console.warn('[interceptor] Extract base64 error:', err);
    }

    try {
      const finalB64 = b64 ? normalizeDataUrl(b64) : '';
      window.dispatchEvent(new CustomEvent('__GRAVITY_EXTRACT_BASE64_RES__' + reqId, {
        detail: { b64: finalB64 }
      }));
    } catch (_) {}
  });
})();

