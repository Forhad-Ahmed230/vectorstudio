(function() {
  if (window.__GRAVITY_EXTENSION_BRIDGE__) return;
  window.__GRAVITY_EXTENSION_BRIDGE__ = true;

  const getExtId = () => (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) ? chrome.runtime.id : '';

  // Listen for messages from the web page
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== 'object') return;

    if (data.type === 'GRAVITY_EXTENSION_PING') {
      window.postMessage({
        type: 'GRAVITY_EXTENSION_PONG',
        extensionId: getExtId(),
        extensionType: 'saas_direct',
        ok: true
      }, '*');
    } else if (data.type === 'GRAVITY_EXTENSION_GENERATE') {
      const payload = data.payload || {};
      const requestId = data.requestId || Date.now();
      try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          chrome.runtime.sendMessage(payload, (response) => {
            const err = chrome.runtime.lastError;
            window.postMessage({
              type: 'GRAVITY_EXTENSION_GENERATE_RESULT',
              requestId: requestId,
              response: response || { ok: false, error: err ? err.message : 'No response from background script' }
            }, '*');
          });
        } else {
          window.postMessage({
            type: 'GRAVITY_EXTENSION_GENERATE_RESULT',
            requestId: requestId,
            response: { ok: false, error: 'Chrome extension runtime not available in this context' }
          }, '*');
        }
      } catch (e) {
        window.postMessage({
          type: 'GRAVITY_EXTENSION_GENERATE_RESULT',
          requestId: requestId,
          response: { ok: false, error: e.message || String(e) }
        }, '*');
      }
    }
  });

  // Proactive announcement on load
  try {
    const extId = getExtId();
    if (extId) {
      window.postMessage({
        type: 'GRAVITY_EXTENSION_PONG',
        extensionId: extId,
        extensionType: 'saas_direct',
        ok: true
      }, '*');
    }
  } catch (e) {}
})();

